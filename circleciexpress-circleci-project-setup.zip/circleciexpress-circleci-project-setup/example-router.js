function exampleRouteHandler(req, res) {
  res.send("Goodbye Earthling!");
}
module.exports = exampleRouteHandler;